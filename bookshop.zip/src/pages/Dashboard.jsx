import React from "react";

function Dashboard() {
  return <div>This is protected </div>;
}

export default Dashboard;
