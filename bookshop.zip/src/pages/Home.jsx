import React, { useEffect, useState } from "react";
import Product from "../components/Product";
import Pages from "../components/Pages";

function Home() {
  const [productData, setProductData] = useState([]);
  const [currentpage, setcurrentpage] = useState(1);

  // it will give all product information
  const url = "https://fakestoreapi.com/products";

  let productPerPage = 2;

  let totalPages = productData.length / productPerPage;

  let lastIndex = productPerPage * currentpage; // 20

  let firstindex = lastIndex - productPerPage; // 15

  let fiteredData = productData.slice(firstindex, lastIndex);

  console.log({ currentpage, firstindex, lastIndex });

  useEffect(() => {
    //code
    // function to get data from api
    async function getDataFromApi() {
      const response = await fetch(url);
      const data = await response.json();
      setProductData(data);
    }
    getDataFromApi();
  }, []);

  return (
    <div>
      <Product productData={fiteredData} />
      <Pages totalPages={totalPages} setcurrentpage={setcurrentpage} />
    </div>
  );
}

export default Home;
