import React from "react";
import "./product.css";
function Product({ productData }) {
  return (
    <div className="outer">
      {productData.map((product) => (
        <div className="product" key={product.id}>
          <h1>{product.title}</h1>
          <img src={product.image} />
          <p>{product.description}</p>
          <h3>Rs: {product.price}</h3>
          <button>Add To Cart</button>
        </div>
      ))}
    </div>
  );
}

export default Product;
