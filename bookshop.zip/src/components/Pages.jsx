import React from "react";

function Pages({ totalPages, setcurrentpage }) {
  let pages = [];

  for (let i = 1; i <= totalPages; i++) {
    pages.push(i);
  }

  return (
    <div>
      {pages.map((page, index) => (
        <button key={index} onClick={() => setcurrentpage(page)}>
          {page}
        </button>
      ))}
    </div>
  );
}

export default Pages;
