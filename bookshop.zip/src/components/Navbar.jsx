import React from "react";
import { Link, NavLink } from "react-router-dom";
import "./navbar.css";

function Navbar() {
  return (
    <div className="navbar">
      <div>
        <NavLink
          to="/"
          className={({ isActive }) => (isActive ? "active-link" : "link")}
        >
          Home
        </NavLink>
      </div>
      <div>
        <NavLink
          to="/login"
          className={({ isActive }) => (isActive ? "active-link" : "link")}
        >
          Login
        </NavLink>
      </div>
      <div>
        <NavLink
          to="/register"
          className={({ isActive }) => (isActive ? "active-link" : "link")}
        >
          Register
        </NavLink>
      </div>
      <div>
        <NavLink
          to="/about"
          className={({ isActive }) => (isActive ? "active-link" : "link")}
        >
          About Us
        </NavLink>
      </div>
    </div>
  );
}

export default Navbar;
